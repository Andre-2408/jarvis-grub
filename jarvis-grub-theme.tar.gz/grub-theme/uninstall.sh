#!/usr/bin/env bash
# Quita el tema "Jarvis" y devuelve GRUB a como estaba antes de instalarlo.
set -euo pipefail

ROOT="${JARVIS_TEST_ROOT:-}"   # solo para pruebas
DEFAULT_FILE="$ROOT/etc/default/grub"
BACKUP_BASE="$ROOT/var/backups/jarvis-grub"

say() { printf '\033[36m[jarvis]\033[0m %s\n' "$*"; }
die() { printf '\033[31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

[ -n "$ROOT" ] || [ "$(id -u)" -eq 0 ] || die "Ejecútalo con sudo:  sudo ./uninstall.sh"
[ -f "$BACKUP_BASE/ultima" ] || die "No encuentro la copia de seguridad en /var/backups/jarvis-grub."
BACKUP_DIR="$BACKUP_BASE/$(cat "$BACKUP_BASE/ultima")"
[ -f "$BACKUP_DIR/default-grub" ] || die "La copia de seguridad está incompleta: $BACKUP_DIR"

GRUB_DIR=""
for d in /boot/grub /boot/grub2; do
  if [ -f "$ROOT$d/grub.cfg" ]; then GRUB_DIR="$d"; break; fi
done
[ -n "$GRUB_DIR" ] || die "No encuentro grub.cfg."

MKCONFIG="$(command -v grub-mkconfig || command -v grub2-mkconfig)" || die "No encuentro grub-mkconfig."
CFG="$ROOT$GRUB_DIR/grub.cfg"

cp -a "$BACKUP_DIR/default-grub" "$DEFAULT_FILE"
TMP_CFG="$(mktemp)"
trap 'rm -f "$TMP_CFG"' EXIT
"$MKCONFIG" -o "$TMP_CFG"
[ -s "$TMP_CFG" ] || die "La configuración generada está vacía; no he tocado el menú."
if grep -qi 'windows' "$CFG" && ! grep -qi 'windows' "$TMP_CFG"; then
  die "Windows desaparecería del menú; no he tocado el menú."
fi
cp "$TMP_CFG" "$CFG"
rm -rf "$ROOT$GRUB_DIR/themes/jarvis"
say "Tema quitado. GRUB vuelve a estar como antes."
