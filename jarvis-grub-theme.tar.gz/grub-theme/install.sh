#!/usr/bin/env bash
# Instala el tema "Jarvis" en GRUB. Ejecutar desde Linux:  sudo ./install.sh
# Guarda copia de seguridad y deshace los cambios si algo no cuadra.
set -euo pipefail

ROOT="${JARVIS_TEST_ROOT:-}"   # solo para pruebas
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="jarvis"
DEFAULT_FILE="$ROOT/etc/default/grub"
BACKUP_BASE="$ROOT/var/backups/jarvis-grub"

say()  { printf '\033[36m[jarvis]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[aviso]\033[0m %s\n' "$*"; }
die()  { printf '\033[31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

first_cmd() { for c in "$@"; do command -v "$c" >/dev/null 2>&1 && { echo "$c"; return 0; }; done; return 1; }

[ -n "$ROOT" ] || [ "$(id -u)" -eq 0 ] || die "Ejecútalo con sudo:  sudo ./install.sh"
[ -f "$HERE/$THEME_NAME/theme.txt" ] || die "No encuentro la carpeta del tema junto a este script."
[ -f "$DEFAULT_FILE" ] || die "No existe /etc/default/grub. ¿Este Linux usa GRUB?"

GRUB_DIR=""
for d in /boot/grub /boot/grub2; do
  if [ -f "$ROOT$d/grub.cfg" ]; then GRUB_DIR="$d"; break; fi
done
[ -n "$GRUB_DIR" ] || die "No encuentro grub.cfg en /boot/grub ni en /boot/grub2."

MKCONFIG="$(first_cmd grub-mkconfig grub2-mkconfig)" || die "No encuentro grub-mkconfig."
MKFONT="$(first_cmd grub-mkfont grub2-mkfont || true)"
SCRIPTCHECK="$(first_cmd grub-script-check grub2-script-check || true)"

CFG="$ROOT$GRUB_DIR/grub.cfg"
THEME_DIR="$ROOT$GRUB_DIR/themes/$THEME_NAME"
THEME_FILE="$GRUB_DIR/themes/$THEME_NAME/theme.txt"

# --- copia de seguridad -------------------------------------------------------
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_BASE/$STAMP"
mkdir -p "$BACKUP_DIR"
cp -a "$DEFAULT_FILE" "$BACKUP_DIR/default-grub"
cp -a "$CFG" "$BACKUP_DIR/grub.cfg"
HAD_THEME=0
if [ -d "$THEME_DIR" ]; then HAD_THEME=1; cp -a "$THEME_DIR" "$BACKUP_DIR/theme-anterior"; fi
echo "$STAMP" > "$BACKUP_BASE/ultima"
say "Copia de seguridad en /var/backups/jarvis-grub/$STAMP"

TMP_CFG="$(mktemp)"
FINISHED=0
rollback() {
  rm -f "$TMP_CFG"
  [ "$FINISHED" -eq 1 ] && return 0
  warn "Algo falló: deshaciendo los cambios. Tu arranque queda como estaba."
  cp -a "$BACKUP_DIR/default-grub" "$DEFAULT_FILE"
  rm -rf "$THEME_DIR"
  if [ "$HAD_THEME" -eq 1 ]; then cp -a "$BACKUP_DIR/theme-anterior" "$THEME_DIR"; fi
}
trap rollback EXIT

# --- archivos del tema ---------------------------------------------------------
rm -rf "$THEME_DIR"
mkdir -p "$(dirname "$THEME_DIR")"
cp -r "$HERE/$THEME_NAME" "$THEME_DIR"

if [ -n "$MKFONT" ]; then
  say "Generando fuentes..."
  for size in 20 26; do
    "$MKFONT" -n JarvisText -s "$size" -o "$THEME_DIR/jarvis-text-$size.pf2" "$HERE/fonts-src/Rajdhani-SemiBold.ttf"
  done
else
  warn "No está grub-mkfont: se usará la fuente básica de GRUB."
  sed -i 's/JarvisText Regular [0-9]*/Unifont Regular 16/' "$THEME_DIR/theme.txt"
fi

# --- /etc/default/grub -----------------------------------------------------------
set_var() { # clave valor
  if grep -Eq "^[#[:space:]]*$1=" "$DEFAULT_FILE"; then
    sed -i -E "0,/^[#[:space:]]*$1=.*/s||$1=$2|" "$DEFAULT_FILE"
  else
    printf '%s=%s\n' "$1" "$2" >> "$DEFAULT_FILE"
  fi
}
set_var GRUB_THEME "\"$THEME_FILE\""
grep -Eq '^GRUB_GFXMODE=' "$DEFAULT_FILE" || set_var GRUB_GFXMODE '"auto"'
set_var GRUB_TIMEOUT_STYLE menu
# Un menú con tiempo 0 no se llegaría a ver.
if ! grep -Eq '^GRUB_TIMEOUT=["'"'"']?[1-9-]' "$DEFAULT_FILE"; then set_var GRUB_TIMEOUT 10; fi
# La salida solo de texto impide mostrar temas gráficos.
sed -i -E 's/^(GRUB_TERMINAL(_OUTPUT)?=["'"'"']?console["'"'"']?.*)$/#\1/' "$DEFAULT_FILE"

# --- generar y verificar ANTES de sustituir el menú real -------------------------
say "Generando el menú de arranque..."
"$MKCONFIG" -o "$TMP_CFG"
[ -s "$TMP_CFG" ] || die "La configuración generada está vacía."
if [ -n "$SCRIPTCHECK" ]; then "$SCRIPTCHECK" "$TMP_CFG" || die "La configuración generada no es válida."; fi
grep -q "$THEME_FILE" "$TMP_CFG" || die "La configuración generada no incluye el tema."

count_entries() { grep -Ec '^[[:space:]]*menuentry ' "$1" || true; }
if grep -qi 'windows' "$CFG" && ! grep -qi 'windows' "$TMP_CFG"; then
  die "Windows desaparecería del menú. Cancelado para protegerte (revisa os-prober)."
fi
if [ "$(count_entries "$TMP_CFG")" -lt 1 ]; then die "El menú generado no tiene ningún sistema."; fi

cp "$TMP_CFG" "$CFG"
FINISHED=1
say "¡Listo! Reinicia para ver a Jarvis en el arranque."
say "Para quitarlo:  sudo ./uninstall.sh"
